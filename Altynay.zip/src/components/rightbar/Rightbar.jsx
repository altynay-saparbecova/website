import React from 'react'
import './rightbar.less'
const Rightbar = () => {
    return (
        <div className="rightbar">
            Rightbar
        </div>
    )
}
export default Rightbar