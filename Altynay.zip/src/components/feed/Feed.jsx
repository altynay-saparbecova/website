import React from 'react'
import './feed.less'
const Feed = () => {
    return (
        <div className='feed'>
            Feed
        </div>
    )
}
export default Feed