import React from 'react'
import './topbar.less'
import SearchIcon from '@material-ui/icons/Search';
// import PersonIcon from '@material-ui/icons/Person';
// import ChatIcon from '@material-ui/icons/Chat';
// import NotificationsActiveIcon from '@material-ui/icons/NotificationsActive';
const Topbar = () => {
    return (
        <div className='topbarContainer'>
            <div className='topbarLeft'>
                <span className='logo'>Lamasocial</span>
            </div>
            <div className='topbarCenter'>
                <div className="searchbar">
                    <SearchIcon className="searchIcon" />
                    <input placeholder='Search for friend,post or video' className='searchInput'></input>
                </div>
            </div>

            <div className='topbarRight'>
                <div className='topbarLinks'>
                    <span className='topbarLink'>Homepage</span>
                    <span className='topbarLink'>Login</span>
                </div>
                <div className="topbarIcons">
                    <button className='topbarIconItem'>SignUp </button>
                    <div className='topbarIconItem'>
                        {/* <ChatIcon /> */}
                        <span className='topbarIconBadge'></span>
                    </div>
                    <div className='topbarIconItem'>
                        {/* <NotificationsActiveIcon /> */}
                        <span className='topbarIconBadge'></span>
                    </div>
                </div>
                <img src="/public/assets/person/1.jpeg" alt='' className="topbarImg" />
            </div>
        </div>
    )

}
export default Topbar