import React from 'react'
import SignUp from '../../components/signup/Signup.jsx'
import Topbar from "../../components/topbar/Topbar.jsx"
// import Sidebar from "../../components/sidebar/Sidebar.jsx"
// import Feed from "../../components/feed/Feed.jsx"
// import Rightbar from "../../components/rightbar/Rightbar.jsx"
import "./home.less"
const Home = () => {
    return (
        <>
            <Topbar />
            <div className="homeContainer">
                <SignUp />
                {/* <Sidebar /> */}
                {/* <Feed /> */}
                {/* <Rightbar /> */}
            </div>
        </>
    )

}
export default Home