import React from 'react';
import Home from './pages/home/Home.jsx'
const App = () => {
    return (
        <div>
            <Home />
        </div>
    )
};


export default App;